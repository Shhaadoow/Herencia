/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo1;

public class Gerente implements Empleado {
    private String nombre;
    private final double tarifaPorHora = 30.0;

    public Gerente(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public double calcularSalario(int horasTrabajadas) {
        return tarifaPorHora * horasTrabajadas;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getRol() {
        return "Gerente";
    }
}
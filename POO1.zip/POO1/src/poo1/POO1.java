/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poo1;
import java.util.Scanner;

public class POO1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BaseDeDatos db = new BaseDeDatos();
        db.conectar();

        System.out.print("Ingrese nombre del empleado: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese rol (Gerente/Desarrollador): ");
        String rol = sc.nextLine();

        System.out.print("Ingrese horas trabajadas: ");
        int horas = sc.nextInt();

        Empleado empleado;

        if (rol.equalsIgnoreCase("Gerente")) {
            empleado = new Gerente(nombre);
        } else {
            empleado = new Desarrollador(nombre);
        }

        double salario = empleado.calcularSalario(horas);

        System.out.println("\nRegistro creado:");
        System.out.println("Nombre: " + empleado.getNombre());
        System.out.println("Rol: " + empleado.getRol());
        System.out.println("Horas trabajadas: " + horas);
        System.out.println("Salario por hora: $30 si es Gerente");   
        System.out.println("Salario por hora: $15 si es Trabajador"); 
        System.out.println("Salario calculado: $" + salario);   

        db.guardarEmpleado(empleado.getNombre(), empleado.getRol(), salario);
        db.cerrar();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo1;

/**
 *
 * @author Usuario iTC
 */
public class Desarrollador implements Empleado {
    private String nombre;
    private final double tarifaPorHora = 15.0;

    public Desarrollador(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public double calcularSalario(int horasTrabajadas) {
        return tarifaPorHora * horasTrabajadas;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getRol() {
        return "Desarrollador";
    }
}
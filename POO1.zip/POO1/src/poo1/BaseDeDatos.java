/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.SQLException;

/**
 *
 * @author Usuario iTC
 */
public class BaseDeDatos {

    private Connection conexion;

    public void conectar() {
        try {
            conexion = DriverManager.getConnection("jdbc:sqlite:empresa.db");
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS empleados (nombre TEXT, rol TEXT, salario REAL)");
            System.out.println("Conectado a la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
    }

    public void guardarEmpleado(String nombre, String rol, double salario) {
        try {
            PreparedStatement pstmt = conexion.prepareStatement("INSERT INTO empleados (nombre, rol, salario) VALUES (?, ?, ?)");
            pstmt.setString(1, nombre);
            pstmt.setString(2, rol);
            pstmt.setDouble(3, salario);
            pstmt.executeUpdate();
            System.out.println("Empleado guardado: " + nombre);
        } catch (SQLException e) {
            System.out.println("Error al guardar empleado: " + e.getMessage());
        }
    }

    public void cerrar() {
        try {
            if (conexion != null) {
                conexion.close();
            }
            System.out.println("Conexión cerrada.");
        } catch (SQLException e) {
            System.out.println("Error al cerrar: " + e.getMessage());
        }
    }

}

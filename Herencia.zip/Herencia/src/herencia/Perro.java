/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author Usuario iTC
 */
public class Perro extends Animal {
    int edad;
    String raza;

    public Perro(String raza, String tipo, int edad) {
        super(tipo, edad);
        this.raza = raza;
        this.edad = edad;
    }

    void ladrido() {
        System.out.println("Guau Guau - Soy un lindo " + raza + " de raza " + tipo);
    }

    public int ProceEdad() {
        if (edad <= 3) {
            System.out.println("Su perro necesita 4 vacunas");
        } else {
            if (edad >= 3) {
                System.out.println("Su perro necesita 3 vacunas");
            }
        }
        return edad;
    }
}

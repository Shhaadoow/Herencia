/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

import java.util.Scanner;

/**
 *
 * @author Usuario iTC
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el nombre del titular: ");
        String titular = sc.nextLine();

        System.out.print("Ingrese el tipo de cuenta (Ahorro o Corriente): ");
        String tipoCta = sc.nextLine();

        if (tipoCta.equalsIgnoreCase("Ahorro")) {
            CtaAhorro cuenta = new CtaAhorro(titular, tipoCta, 5);
            cuenta.mostrarTitular();
            System.out.println("Tipo de cuenta: " + cuenta.tipo);
            cuenta.interes();
        } else if (tipoCta.equalsIgnoreCase("Corriente")) {
            CtaCorriente cuenta = new CtaCorriente(titular, tipoCta, 7);
            cuenta.mostrarTitular();
            System.out.println("Tipo de cuenta: " + cuenta.tipo);
            cuenta.interes();
        } 
    }
}
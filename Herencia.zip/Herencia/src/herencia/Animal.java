/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author Usuario iTC
 */
public class Animal {
    String tipo;
    int edad;

    public Animal(String tipo, int edad) {
        this.tipo = tipo;
        this.edad = edad;
    }

    void Describir() {
        System.out.println("Mi tipo es: " + tipo);
    }

    void Edad() {
        if (edad <= 3) {
            System.out.println("Su perro aún es joven");
        } else {
            if (edad >= 3.1) {
                System.out.println("Su perro ya es mayorcito");
            }
        }

    }
}

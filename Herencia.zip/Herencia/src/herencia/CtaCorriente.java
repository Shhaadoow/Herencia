/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;
import java.util.Scanner;
/**
 *
 * @author Usuario iTC
 */
public class CtaCorriente extends Cuenta {

    double saldo;
    int interes;

    public CtaCorriente(String titular, String tipo, int interes) {
        super(titular, tipo);
        this.saldo = pedirSaldo();
        this.interes = interes;
    }

    public double pedirSaldo() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el saldo de la cuenta: ");
        return sc.nextDouble();
    }

    public void interes() {
        double interesCalculado = (saldo * interes) / 100;
        double saldoFinal = saldo + interesCalculado;
        System.out.println("Su saldo original es: " + saldo);
        System.out.println("El interés del 7% es: " + interesCalculado);
        System.out.println("Su saldo con interés es: " + saldoFinal);
    }
}

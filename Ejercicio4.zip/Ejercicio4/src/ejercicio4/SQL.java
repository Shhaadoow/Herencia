/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author utpl
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// NotasDAO.java: solo SQL
public class SQL {

    private static final String DB_URL = "jdbc:sqlite:C:/Users/utpl/Documents/NetBeansProjects/Ejercicio4/estudiantes.db";

    public void crearTabla() {
        String sql = "CREATE TABLE IF NOT EXISTS notas ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "idEstudiante TEXT,"
                + "materia TEXT,"
                + "nota REAL)";
        try (Connection conn = DriverManager.getConnection(DB_URL); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("Error creando tabla: " + e.getMessage());
        }
    }

    public void insertarNota(Notas nota) {
        String sql = "INSERT INTO notas (idEstudiante, materia, nota) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nota.getIdEstudiante());
            pstmt.setString(2, nota.getMateria());
            pstmt.setDouble(3, nota.getNota());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error insertando nota: " + e.getMessage());
        }
    }

    public List<Notas> obtenerNotas(String idEstudiante) {
        List<Notas> lista = new ArrayList<>();
        String sql = "SELECT materia, nota FROM notas WHERE idEstudiante = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, idEstudiante);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Notas n = new Notas(idEstudiante, rs.getString("materia"), rs.getDouble("nota"));
                lista.add(n);
            }
        } catch (SQLException e) {
            System.out.println("Error obteniendo notas: " + e.getMessage());
        }
        return lista;
    }

    public double obtenerPromedio(String idEstudiante) {
        String sql = "SELECT AVG(nota) as promedio FROM notas WHERE idEstudiante = ?";
        double promedio = 0;
        try (Connection conn = DriverManager.getConnection(DB_URL); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, idEstudiante);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                promedio = rs.getDouble("promedio");
            }
        } catch (SQLException e) {
            System.out.println("Error calculando promedio: " + e.getMessage());
        }
        return promedio;
    }
}

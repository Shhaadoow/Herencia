/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author utpl
 */

import java.util.List;

// GestorNotas.java: lógica para agregar, mostrar y calcular promedio
public class GestorNotas {
    private SQL notasDAO;

    public GestorNotas() {
        this.notasDAO = new SQL();
        this.notasDAO.crearTabla();
    }

    public void agregarNota(Notas nota) {
        notasDAO.insertarNota(nota);
    }

    public List<Notas> mostrarNotas(String idEstudiante) {
        return notasDAO.obtenerNotas(idEstudiante);
    }

    public double calcularPromedio(String idEstudiante) {
        return notasDAO.obtenerPromedio(idEstudiante);
    }
}


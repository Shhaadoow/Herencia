/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author utpl
 */
import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        SQL sql = new SQL();
        sql.crearTabla();

        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\n=== Menú Gestión de Notas ===");
            System.out.println("1. Agregar nota");
            System.out.println("2. Mostrar notas de un estudiante");
            System.out.println("3. Calcular promedio de un estudiante");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir salto de línea

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese ID del estudiante: ");
                    String idEstudiante = scanner.nextLine();

                    System.out.print("Ingrese materia: ");
                    String materia = scanner.nextLine();

                    System.out.print("Ingrese nota: ");
                    double nota = scanner.nextDouble();
                    scanner.nextLine(); // Consumir salto de línea

                    Notas nuevaNota = new Notas(idEstudiante, materia, nota);
                    sql.insertarNota(nuevaNota);
                    System.out.println("Nota agregada correctamente.");
                    break;

                case 2:
                    System.out.print("Ingrese ID del estudiante: ");
                    String idEstudianteMostrar = scanner.nextLine();

                    List<Notas> notas = sql.obtenerNotas(idEstudianteMostrar);
                    if (notas.isEmpty()) {
                        System.out.println("No se encontraron notas para ese estudiante.");
                    } else {
                        System.out.println("Notas del estudiante " + idEstudianteMostrar + ":");
                        for (Notas n : notas) {
                            System.out.println(n);
                        }
                    }
                    break;

                case 3:
                    System.out.print("Ingrese ID del estudiante: ");
                    String idEstudiantePromedio = scanner.nextLine();

                    double promedio = sql.obtenerPromedio(idEstudiantePromedio);
                    if (promedio == 0) {
                        System.out.println("No se encontró promedio (posiblemente no hay notas).");
                    } else {
                        System.out.println("Promedio del estudiante " + idEstudiantePromedio + ": " + promedio);
                    }
                    break;

                case 4:
                    salir = true;
                    System.out.println("Saliendo del programa...");
                    break;

                default:
                    System.out.println("Opción no válida, intente de nuevo.");
            }
        }

        scanner.close();
    }
}

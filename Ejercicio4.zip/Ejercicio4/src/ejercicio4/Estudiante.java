/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author utpl
 */
public class Estudiante extends Persona {

    private String idEstudiante;
    private String ciclo;

    public Estudiante(String nombre, String apellido, int edad, String idEstudiante, String ciclo) {
        super(nombre, apellido, edad);
        this.idEstudiante = idEstudiante;
        this.ciclo = ciclo;
    }

    public String getIdEstudiante() {
        return idEstudiante;
    }

    public String getCiclo() {
        return ciclo;
    }

    public void setIdEstudiante(String idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public void setCiclo(String ciclo) {
        this.ciclo = ciclo;
    }

    @Override
    public String toString() {
        return super.toString() + ", ID: " + idEstudiante + ", Ciclo: " + ciclo;
    }
}

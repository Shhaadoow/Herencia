/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author utpl
 */
public class Notas {

    private String idEstudiante;
    private String materia;
    private double nota;

    public Notas(String idEstudiante, String materia, double nota) {
        this.idEstudiante = idEstudiante;
        this.materia = materia;
        this.nota = nota;
    }

    // Getters y Setters
    public String getIdEstudiante() {
        return idEstudiante;
    }

    public String getMateria() {
        return materia;
    }

    public double getNota() {
        return nota;
    }

    @Override
    public String toString() {
        return "Materia: " + materia + ", Nota: " + nota;
    }
}
